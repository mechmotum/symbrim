"""Module containing other models, which are neither bicycles nor riders."""

__all__ = ["RollingDisc"]

from brim.other.rolling_disc import RollingDisc
